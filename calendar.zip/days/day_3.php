<?php if(isset($quit_scroll)&&$quit_scroll==true){

	$scroll = "hide_scroll";

}
else{
	$scroll = "scroll";
}

?>

<div class="wrapper <?php echo $scroll; ?>" >

	<div class="day container day_03" id="day_3">
		<a href="http://www.att.com/shop/wireless/accessories/special-offer.html" class="btn btn_aprende">
			<img src="img/aprende.png">	
		</a>
		<img src="img/day_03.png" class="display">
		
	</div>

	<span class="next"><a href="4"></a></span>

</div>
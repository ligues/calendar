<?php if(isset($quit_scroll)&&$quit_scroll==true){

	$scroll = "hide_scroll";

}
else{
	$scroll = "scroll";
}

?>

<div class="wrapper <?php echo $scroll; ?>" >

<div class="day container day_05"  id="day_5">
	<a href="#" class="btn btn_comparte">
		<img src="img/comparte.png">	
	</a>
	<img src="img/day_05.png" class="display">
	<span class="next"><a href="6"></a></span>
</div>
</div>
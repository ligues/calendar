<?php if(isset($quit_scroll)&&$quit_scroll==true){

	$scroll = "hide_scroll";

}
else{
	$scroll = "scroll";
}

?>

<div class="wrapper <?php echo $scroll; ?>" >
<div class="day container day_12"  id="day_12">
	<a href="#" class="btn btn_comparte">
		<img src="img/comparte.png">	
	</a>
	<img src="img/day_12.png" class="display">
</div>
</div>